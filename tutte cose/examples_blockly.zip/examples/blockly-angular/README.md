[Home](../README.md)

# blockly-angular-sample [![Built on Blockly](https://tinyurl.com/built-on-blockly)](https://github.com/google/blockly)

This sample shows how to load Blockly in an [Angular](https://angular.io/) project.

## Installation

```
npm install
```

## Running

```
npm run start
```

## Browse

Open [http://localhost:3000/](http://localhost:3000/)